from typing import List
from .config import ConfigMgr
from .dcmi import dcmi
from .topo import TopoSingleFactory
from .npu import NPU, EID, IP, process_roce
from .tool import get_server_unique_id
from .urma_device import UrmaDevice, get_urma_device_list


def process_level0(npu):
    """
    v2规则中， die id和物理口id按照规则编码
    """
    topo = TopoSingleFactory.get_topo()
    #for eid in npu.addr_list:
    max_fe = 0
    mesh_dev = None
    for urma_dev in npu.urma_dev_list:
        try:
            fe = urma_dev.get_fe_id()
            die_id = urma_dev.get_die_id()
        except Exception:
            continue
        if ((npu.device_id % 8) < 4 and die_id == 1) or ((npu.device_id % 8) >= 4 and die_id == 0):
            # POD前4个NPU使用0die组mesh，后4个NPU使用1die组mesh
            continue
        if fe > max_fe:
            max_fe = fe
            mesh_dev = urma_dev

    pg_eid = mesh_dev.get_pg_eid()
    for eid in mesh_dev.eid_list:
        if eid == pg_eid:
            continue
        p = mesh_dev.get_phy_port_by_eid(eid)
        die_id = mesh_dev.get_die_id_by_eid(eid)
        ports = [f"{die_id}/{p}"]
        plane_id = f"plane_{die_id}"
        npu.level(0).append(EID(eid, ports, plane_id))

    #server_id = get_server_unique_id()
    sp_id = ConfigMgr().get("super_pod_id")
    server_index = ConfigMgr().get("server_index")
    npu.level(0).net_instance_id = f"sp_{sp_id}_srv_{server_index}"

def get_level1_config(phy_id):
    """
    获取端口规则 (die_id, fe_id, (ports))
    """
    mainboard_id = ConfigMgr().get("mainboard_id")
    if mainboard_id == 3 and (phy_id % 8 ) < 4:
        return [(0, 2,(1, 2)), (1, 2, (0,1,2,3,5,6))]
    if mainboard_id == 3 and (phy_id % 8 ) >= 4:
        return [(1, 2,(1, 2)), (0, 2, (0,1,2,3,4,5))]

def process_level1(npu):
    configs = get_level1_config(npu.device_id)
    for urma_dev in npu.urma_dev_list:
        fe_id = urma_dev.get_fe_id()
        try:
            die_id = urma_dev.get_die_id()
            eid = urma_dev.get_pg_eid()
        except Exception:
            continue
        for target_die, target_fe, ports in configs:
            if die_id == target_die and fe_id == target_fe:
                port_list = [f"{die_id}/{p}" for p in ports]
                plane_id = f"plane_pg_{0 if (len(ports) == 6) else 1}"
                npu.level(1).append(EID(eid, port_list, plane_id))

    npu.level(1).net_instance_id = f"""superpod_{ConfigMgr().get("super_pod_id")}"""

def process_npu_for_pod(npu):
    max_level = int(ConfigMgr().get("max_level"))
    levels = TopoSingleFactory.get_topo().get_level_list()[:max_level]
    for level in levels:
        if level == 0:
            try:
                process_level0(npu)
            except Exception as e:
                print(f"NPU {npu.device_id} level {level} exception {e}")
        if level == 1:
            try:
                process_level1(npu)
            except Exception as e:
                print(f"NPU {npu.device_id} level {level} exception {e}")
        if level == 3:
            try:
                process_roce(npu, level)
            except Exception as e:
                print(f"NPU {npu.device_id} level {level} exception {e}")

def process_rootinfo_pod(rootinfo):
    for npu in rootinfo.rank_list:
        try:
            npu.urma_dev_list = get_urma_device_list(npu.npu_id, "pod")
            process_npu_for_pod(npu)
        except Exception as e:
            print(e)